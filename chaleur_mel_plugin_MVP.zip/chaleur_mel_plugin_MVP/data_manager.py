import json
import zipfile
from pathlib import Path

from qgis.core import QgsApplication, QgsBlockingNetworkRequest
from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtNetwork import QNetworkRequest

# TODO mettre l'url du latest.json
LATEST_JSON_URL = (
    "https://raw.githubusercontent.com/A_COMPLETER/chaleur-mel/main/latest.json"
)


class DataManager:

    def __init__(self):
        profil = Path(QgsApplication.qgisSettingsDirPath())
        self.data_dir = profil / "chaleur_mel_data"
        self.data_dir.mkdir(parents=True, exist_ok=True)

    @property
    def gpkg_path(self):
        return self.data_dir / "chaleur_mel.gpkg"

    @property
    def manifest_path(self):
        return self.data_dir / "manifest.json"

    def pack_present(self):
        return self.gpkg_path.exists() and self.manifest_path.exists()

    def version_locale(self):
        if not self.manifest_path.exists():
            return None
        try:
            return json.loads(self.manifest_path.read_text(encoding="utf-8")).get("version")
        except (json.JSONDecodeError, OSError):
            return None

    def manifest(self):
        if not self.manifest_path.exists():
            return {}
        try:
            return json.loads(self.manifest_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}

    def raster_lst_courant(self):
        scenes = self.manifest().get("scenes_lst", [])
        if not scenes:
            return None
        derniere = sorted(scenes, key=lambda s: s.get("date", ""))[-1]
        chemin = self.data_dir / "lst" / derniere["fichier"]
        return chemin if chemin.exists() else None

    @staticmethod
    def _get(url):
        req = QgsBlockingNetworkRequest()
        if req.get(QNetworkRequest(QUrl(url))) != QgsBlockingNetworkRequest.NoError:
            return None
        return bytes(req.reply().content())

    def version_distante(self):
        contenu = self._get(LATEST_JSON_URL)
        if contenu is None:
            return None
        try:
            return json.loads(contenu.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            return None

    def mise_a_jour_disponible(self):
        distant = self.version_distante()
        if not distant:
            return None
        if distant.get("version") != self.version_locale():
            return distant
        return None

    def telecharger_pack(self, info):
        contenu = self._get(info["url"])
        if contenu is None:
            return False
        zip_path = self.data_dir / "pack_tmp.zip"
        zip_path.write_bytes(contenu)
        try:
            with zipfile.ZipFile(zip_path) as z:
                z.extractall(self.data_dir)
        except zipfile.BadZipFile:
            return False
        finally:
            zip_path.unlink(missing_ok=True)
        # des fois le zip a un dossier pack en plus
        racine = self.data_dir / "pack"
        if racine.is_dir():
            for item in racine.iterdir():
                cible = self.data_dir / item.name
                if cible.exists():
                    if cible.is_dir():
                        import shutil
                        shutil.rmtree(cible)
                    else:
                        cible.unlink()
                item.rename(cible)
            racine.rmdir()
        return self.pack_present()
