from pathlib import Path

from qgis.core import (
    NULL,
    Qgis,
    QgsColorRampShader,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureRequest,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsRasterLayer,
    QgsRasterShader,
    QgsRectangle,
    QgsSingleBandPseudoColorRenderer,
    QgsSpatialIndex,
    QgsVectorLayer,
)
from qgis.gui import QgsRubberBand
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QIcon
from qgis.PyQt.QtWidgets import (
    QAction,
    QApplication,
    QDialog,
    QDockWidget,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from .data_manager import DataManager
from .geocoder import geocoder

CRS_PACK = QgsCoordinateReferenceSystem("EPSG:2154")
CRS_WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")


class ChaleurMelPlugin:

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dock = None
        self.dm = DataManager()
        self.couche_parcelles = None
        self.couche_troncons = None
        self.index_troncons = None
        self.rubber = None

    def initGui(self):
        icone = Path(__file__).parent / "icon.png"
        self.action = QAction(QIcon(str(icone)), "Chaleur MEL", self.iface.mainWindow())
        self.action.triggered.connect(self.ouvrir)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("Chaleur MEL", self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu("Chaleur MEL", self.action)
        self._effacer_surbrillance()
        if self.dock:
            self.iface.removeDockWidget(self.dock)
            self.dock = None

    def _assurer_pack(self):
        if self.dm.pack_present():
            maj = self.dm.mise_a_jour_disponible()
            if maj and QMessageBox.question(
                    self.iface.mainWindow(), "Chaleur MEL",
                    f"Une mise à jour des données est disponible "
                    f"(version {maj['version']}). La télécharger ?",
            ) == QMessageBox.Yes:
                self._telecharger(maj)
            return True

        info = self.dm.version_distante()
        if not info:
            QMessageBox.warning(
                self.iface.mainWindow(), "Chaleur MEL",
                "Pack de données absent et serveur injoignable.\n"
                "Vérifiez votre connexion internet puis relancez le plugin.")
            return False

        if QMessageBox.question(
                self.iface.mainWindow(), "Chaleur MEL",
                f"Premier lancement : le pack de données MEL "
                f"(version {info['version']}) doit être téléchargé. Continuer ?",
        ) != QMessageBox.Yes:
            return False
        return self._telecharger(info)

    def _telecharger(self, info):
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            ok = self.dm.telecharger_pack(info)
        finally:
            QApplication.restoreOverrideCursor()
        if not ok:
            QMessageBox.critical(self.iface.mainWindow(), "Chaleur MEL",
                                 "Échec du téléchargement du pack de données.")
        return ok

    def _charger_couches(self):
        gpkg = str(self.dm.gpkg_path)
        self.couche_parcelles = QgsVectorLayer(f"{gpkg}|layername=parcelles",
                                               "parcelles_mel", "ogr")
        self.couche_troncons = QgsVectorLayer(f"{gpkg}|layername=troncons",
                                              "troncons_mel", "ogr")
        if not (self.couche_parcelles.isValid() and self.couche_troncons.isValid()):
            QMessageBox.critical(self.iface.mainWindow(), "Chaleur MEL",
                                 "GeoPackage du pack illisible ou incomplet.")
            return False
        self.index_troncons = QgsSpatialIndex(self.couche_troncons.getFeatures())

        self._assurer_fond_et_lst()
        return True

    def _assurer_fond_et_lst(self):
        projet = QgsProject.instance()
        racine = projet.layerTreeRoot()

        if not projet.mapLayersByName("OpenStreetMap"):
            osm = QgsRasterLayer(
                "type=xyz&url=https://tile.openstreetmap.org/%7Bz%7D/%7Bx%7D/%7By%7D.png"
                "&zmax=19&zmin=0",
                "OpenStreetMap", "wms")
            if osm.isValid():
                projet.addMapLayer(osm, False)
                racine.insertLayer(-1, osm)

        raster = self.dm.raster_lst_courant()
        if raster and not projet.mapLayersByName("LST (chaleur MEL)"):
            rl = QgsRasterLayer(str(raster), "LST (chaleur MEL)")
            if not rl.isValid():
                return
            stats = rl.dataProvider().bandStatistics(1)
            mini, maxi = stats.minimumValue, stats.maximumValue
            shader_fn = QgsColorRampShader(mini, maxi)
            shader_fn.setColorRampType(QgsColorRampShader.Interpolated)
            pas = (maxi - mini) or 1.0
            shader_fn.setColorRampItemList([
                QgsColorRampShader.ColorRampItem(mini, QColor(43, 131, 186), f"{mini:.1f} °C"),
                QgsColorRampShader.ColorRampItem(mini + 0.5 * pas, QColor(255, 255, 141),
                                                 f"{mini + 0.5 * pas:.1f} °C"),
                QgsColorRampShader.ColorRampItem(maxi, QColor(215, 25, 28), f"{maxi:.1f} °C"),
            ])
            shader = QgsRasterShader()
            shader.setRasterShaderFunction(shader_fn)
            rl.setRenderer(QgsSingleBandPseudoColorRenderer(rl.dataProvider(), 1, shader))
            rl.setOpacity(0.55)
            projet.addMapLayer(rl, False)
            racine.insertLayer(0, rl)

    def ouvrir(self):
        if not self._assurer_pack() or not self._charger_couches():
            return
        if self.dock is None:
            self._construire_dock()
        self.dock.show()
        self.champ.setFocus()

    def _construire_dock(self):
        self.dock = QDockWidget("Chaleur MEL", self.iface.mainWindow())
        conteneur = QWidget()
        layout = QVBoxLayout(conteneur)

        self.champ = QLineEdit()
        self.champ.setPlaceholderText("Tapez une adresse dans la MEL…")
        self.champ.returnPressed.connect(self._rechercher)
        layout.addWidget(self.champ)

        bouton = QPushButton("Rechercher")
        bouton.clicked.connect(self._rechercher)
        layout.addWidget(bouton)

        self.liste = QListWidget()
        self.liste.setSpacing(4)
        self.liste.setStyleSheet(
            "QListWidget{background:#f3f4f1;border:0;}"
            "QListWidget::item{background:white;border:1px solid #ddd;"
            "border-radius:6px;padding:10px;}"
            "QListWidget::item:hover{background:#fff3ed;border-color:#e56b3f;}"
            "QListWidget::item:selected{background:#ffe7dc;color:#222;}"
        )
        self.liste.itemClicked.connect(self._choisir_candidat)
        layout.addWidget(self.liste)

        aide = QLabel("Cliquez sur une adresse dans la liste pour ouvrir sa fiche.")
        aide.setWordWrap(True)
        aide.setStyleSheet("color:#888;font-size:11px;padding:4px;")
        layout.addWidget(aide)

        self.dock.setWidget(conteneur)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)

    def _rechercher(self):
        self.liste.clear()
        candidats = geocoder(self.champ.text())
        if not candidats:
            self.iface.messageBar().pushMessage(
                "Chaleur MEL", "Aucune adresse trouvée (ou réseau indisponible).",
                level=Qgis.Warning, duration=4)
            return
        for c in candidats:
            item = QListWidgetItem(c["label"])
            item.setData(Qt.UserRole, c)
            self.liste.addItem(item)

    def _choisir_candidat(self, item):
        c = item.data(Qt.UserRole)
        tr = QgsCoordinateTransform(CRS_WGS84, CRS_PACK, QgsProject.instance())
        point = tr.transform(QgsPointXY(c["lon"], c["lat"]))
        self._afficher_fiche(point, c["label"])

    def _parcelle_au_point(self, point):
        g = QgsGeometry.fromPointXY(point)
        rect = QgsRectangle(point.x() - 1, point.y() - 1, point.x() + 1, point.y() + 1)
        for f in self.couche_parcelles.getFeatures(QgsFeatureRequest(rect)):
            if f.geometry().contains(g):
                return f
        return None

    def _troncon_le_plus_proche(self, point):
        ids = self.index_troncons.nearestNeighbor(point, 1)
        if not ids:
            return None, 0.0
        f = next(self.couche_troncons.getFeatures(QgsFeatureRequest(ids[0])), None)
        if f is None:
            return None, 0.0
        dist = f.geometry().distance(QgsGeometry.fromPointXY(point))
        return f, dist

    @staticmethod
    def _val(feature, champ, fmt="{}", defaut="–"):
        try:
            v = feature[champ]
        except KeyError:
            return defaut
        if v is None or v == NULL or (isinstance(v, float) and v != v):
            return defaut
        try:
            return fmt.format(v)
        except (ValueError, TypeError):
            return str(v)

    EXPLICATIONS = {
        "surface": "Température de la peau des surfaces (sol, toits) vue par "
                   "satellite, comparée à la moyenne de la métropole. Révèle les "
                   "secteurs qui emmagasinent la chaleur le jour.",
        "air": "Chaleur de l'air ressentie la nuit, modélisée par Météo-France. "
               "C'est ce qui pèse sur le sommeil et la santé en canicule.",
        "lcz": "Classification du tissu urbain (Cerema). Les formes denses et "
               "minérales chauffent plus que les tissus aérés ou végétalisés.",
        "imperm": "Part de sols artificialisés (bitume, béton) qui stockent la "
                  "chaleur au lieu de l'évacuer.",
        "vegetation": "Part de végétation, qui rafraîchit par évapotranspiration. "
                      "Plus il y en a, plus le secteur reste tempéré.",
        "ces": "Emprise au sol des bâtiments sur la parcelle. Un bâti dense laisse "
               "peu de place au rafraîchissement.",
        "hauteur": "Hauteur moyenne du bâti. Les rues encaissées piègent la chaleur "
                   "et ralentissent son évacuation la nuit.",
        "rga": "Aléa retrait-gonflement des argiles (BRGM). Les sols argileux se "
               "rétractent lors des sécheresses et peuvent fissurer les bâtiments.",
    }

    @staticmethod
    def _date_fr(iso):
        try:
            a, m, j = str(iso).split("-")
            return f"{j}/{m}/{a}"
        except ValueError:
            return str(iso)

    @staticmethod
    def _reperes_agent(suhi, imperm, veg, rga_txt):
        r = []
        if suhi is not None:
            if suhi >= 2:
                r.append("Secteur nettement plus chaud que la moyenne : confort "
                         "d'été à examiner (orientation, ventilation, occultations).")
            elif suhi <= -1:
                r.append("Secteur plus frais que la moyenne : atout de confort estival.")
            else:
                r.append("Chaleur de surface proche de la moyenne métropolitaine.")
        if veg is not None and veg >= 0.4:
            r.append("Bonne présence de végétation à proximité : facteur de fraîcheur "
                     "et de cadre de vie.")
        if imperm is not None and imperm >= 0.7:
            r.append("Environnement très minéral : peu d'espaces de fraîcheur immédiats.")
        if rga_txt in ("moyen", "fort"):
            r.append(f"Sols argileux (aléa {rga_txt}) : un diagnostic géotechnique "
                     "peut être requis avant construction ou extension.")
        if not r:
            r.append("Pas de point de vigilance particulier sur les données disponibles.")
        return r

    def _ouvrir_fenetre(self, corps, adresse):
        fenetre = QDialog(self.iface.mainWindow())
        fenetre.setWindowTitle("Diagnostic chaleur - " + adresse)
        fenetre.resize(760, 720)

        layout = QVBoxLayout(fenetre)
        try:
            from qgis.PyQt.QtWebEngineWidgets import QWebEngineView
            fiche = QWebEngineView()
        except ImportError:
            fiche = QTextBrowser()
            fiche.setOpenExternalLinks(True)

        page = """
        <!DOCTYPE html>
        <html>
        <head>
        <meta charset='utf-8'>
        <style>
            body {
                font-family: Segoe UI, Arial, sans-serif;
                background: #f3f4f1;
                color: #263238;
                margin: 0;
                padding: 18px;
                font-size: 14px;
                line-height: 1.45;
            }
            .hero {
                background: white;
                border: 1px solid #e4e6e2;
                border-top: 6px solid #e56b3f;
                padding: 20px 22px;
                border-radius: 12px;
                margin-bottom: 14px;
            }
            .hero .petit {
                color: #d35d35;
                font-size: 11px;
                font-weight: bold;
                letter-spacing: 1.2px;
                margin-bottom: 10px;
            }
            .hero .adresse-label {
                color: #6f797d;
                font-size: 12px;
                margin-bottom: 2px;
            }
            .hero h1 {
                color: #111;
                font-size: 22px;
                margin: 0 0 8px 0;
            }
            .hero .parcelle {
                color: #31383b;
                font-size: 13px;
                margin-bottom: 8px;
            }
            .hero .source {
                color: #7a8589;
                font-size: 12px;
            }
            .card {
                background: white;
                border: 1px solid #e4e6e2;
                border-radius: 12px;
                padding: 17px 19px;
                margin: 0 0 13px 0;
            }
            .card h2 {
                font-size: 16px;
                margin: 0 0 12px 0;
                color: #34454b;
            }
            .metrics { width: 100%; border-spacing: 8px 0; }
            .metrics td { width: 50%; vertical-align: top; }
            .metric {
                background: #f7f8f5;
                border-radius: 10px;
                padding: 15px;
                min-height: 125px;
            }
            .metric .label { color: #68777d; font-size: 12px; }
            .metric .value { font-size: 25px; font-weight: bold; margin: 3px 0; }
            .metric .detail { color: #7c898e; font-size: 11px; }
            .metric .info { color: #7a8589; font-size: 11px; margin-top: 9px; }
            .cool { color: #287a9f; }
            .tag {
                display: inline-block;
                background: #edf2f2;
                border-radius: 14px;
                padding: 5px 10px;
                font-weight: bold;
                margin-top: 4px;
            }
            .indicator {
                padding: 10px 5px;
                border-bottom: 1px solid #edf0ed;
            }
            .indicator:last-child { border-bottom: 0; }
            .indicator-line { width: 100%; }
            .indicator-name { font-weight: 600; }
            .indicator-value { float: right; font-weight: bold; }
            .indicator-info {
                clear: both;
                color: #7a8589;
                font-size: 12px;
                padding-top: 4px;
            }
            .infos { width: 100%; border-collapse: collapse; }
            .infos td {
                padding: 9px 6px;
                border-bottom: 1px solid #edf0ed;
            }
            .infos td:last-child { text-align: right; font-weight: bold; }
            .explain { color: #7a8589; font-size: 12px; margin: 7px 0 2px 0; }
            .warning {
                background: #fff6d9;
                border-left: 4px solid #e0a21b;
                padding: 9px 11px;
                margin-top: 8px;
                color: #785a13;
            }
            .repere {
                background: #f6f1df;
                border-left: 4px solid #c8a84e;
                padding: 9px 11px;
                margin: 7px 0;
            }
            .note { color: #8a9498; font-size: 11px; margin-top: 10px; }
            .rga { font-weight: bold; text-transform: capitalize; }
        </style>
        </head>
        <body>
        """ + corps + "</body></html>"

        fiche.setHtml(page)
        layout.addWidget(fiche, stretch=1)

        ligne_bouton = QHBoxLayout()
        ligne_bouton.addStretch()
        fermer = QPushButton("Fermer")
        fermer.setMinimumWidth(100)
        fermer.clicked.connect(fenetre.accept)
        ligne_bouton.addWidget(fermer)
        layout.addLayout(ligne_bouton)

        fenetre.exec()

    def _afficher_fiche(self, point, adresse):
        parc = self._parcelle_au_point(point)
        tron, dist = self._troncon_le_plus_proche(point)

        if parc is None:
            html = (
                "<div class='hero'><div class='petit'>DIAGNOSTIC CHALEUR</div>"
                "<div class='adresse-label'>Adresse exacte</div>"
                "<h1>" + adresse + "</h1></div>"
                "<div class='card'><h2>Adresse non disponible</h2>"
                "<p>Cette adresse est hors de la Métropole Européenne de Lille "
                "ou en dehors des données chargées.</p></div>")
            self._ouvrir_fenetre(html, adresse)
            return

        v = self._val

        def num(champ):
            try:
                x = parc[champ]
                return float(x) if x not in (None, NULL) and x == x else None
            except (KeyError, ValueError, TypeError):
                return None

        suhi_n = num("suhi_parcelle_c")
        imperm_n = num("taux_imperm")
        veg_n = num("frac_vegetale")

        source = v(parc, "suhi_source").upper()
        date_obs = self._date_fr(v(parc, "suhi_date"))
        moment = v(parc, "suhi_moment")
        parcelle_cadastrale = v(parc, "idu")

        rga_raw = v(parc, "rga_alea", defaut="")
        libelles_rga = {"1": "faible", "2": "moyen", "3": "fort",
                        "1.0": "faible", "2.0": "moyen", "3.0": "fort"}
        rga_txt = libelles_rga.get(str(rga_raw).strip(), str(rga_raw)) if rga_raw else ""

        averts = []
        if v(parc, "suhi_fiabilite") == "heritee":
            averts.append("La parcelle est plus petite que le pixel satellite : "
                          "la valeur vient du voisinage immédiat.")
        champs = parc.fields().names()
        if "suhi_est_modele" in champs and str(parc["suhi_est_modele"]) in ("1", "true", "True"):
            averts.append("Cette valeur vient d'une descente d'échelle par modèle.")

        if suhi_n is None:
            couleur = "#6f7b80"
            tendance = "Donnée non disponible"
        elif suhi_n >= 2:
            couleur = "#d84b32"
            tendance = "Secteur plus chaud que la moyenne"
        elif suhi_n <= -1:
            couleur = "#287a9f"
            tendance = "Secteur plus frais que la moyenne"
        else:
            couleur = "#d18b27"
            tendance = "Proche de la moyenne métropolitaine"

        bloc_averts = "".join(
            "<div class='warning'>⚠ " + a + "</div>" for a in averts)

        def indicateur(nom, valeur, explication):
            return (
                "<div class='indicator'>"
                "<div class='indicator-line'><span class='indicator-name'>" + nom + "</span>"
                "<span class='indicator-value'>" + valeur + "</span></div>"
                "<div class='indicator-info'>ⓘ " + explication + "</div>"
                "</div>")

        html = (
            "<div class='hero'>"
            "<div class='petit'>DIAGNOSTIC CHALEUR</div>"
            "<div class='adresse-label'>Adresse exacte</div>"
            "<h1>" + adresse + "</h1>"
            "<div class='parcelle'>Parcelle cadastrale : <strong>" + parcelle_cadastrale + "</strong></div>"
            "<div class='source'>" + source + " · " + date_obs + " · " + moment + "</div>"
            "</div>"

            "<div class='card'>"
            "<table class='metrics'><tr>"
            "<td><div class='metric'><div class='label'>Chaleur de surface</div>"
            "<div class='value' style='color:" + couleur + ";'>"
            + v(parc, 'suhi_parcelle_c', '{:+.1f} °C') + "</div>"
            "<div class='detail'>" + tendance + "</div>"
            "<div class='info'>ⓘ " + self.EXPLICATIONS["surface"] + "</div></div></td>"
            "<td><div class='metric'><div class='label'>Air la nuit</div>"
            "<div class='value cool'>" + v(parc, 'icu_air_nuit_c', '{:+.1f} °C') + "</div>"
            "<div class='detail'>Donnée Météo-France</div>"
            "<div class='info'>ⓘ " + self.EXPLICATIONS["air"] + "</div></div></td>"
            "</tr></table>"
            + bloc_averts +
            "</div>"

            "<div class='card'><h2>🏙️ Le quartier</h2>"
            "<div>Type LCZ : <span class='tag'>" + v(parc, 'lcz_code') + "</span> "
            "<span style='color:#7a8589;'>sensibilité " + v(parc, 'lcz_sensibilite') + "</span></div>"
            "<p class='explain'>ⓘ " + self.EXPLICATIONS["lcz"] + "</p></div>"

            "<div class='card'><h2>🌿 Ce qui joue sur la chaleur</h2>"
            + indicateur("Surfaces imperméables", v(parc, 'taux_imperm', '{:.0%}'), self.EXPLICATIONS["imperm"])
            + indicateur("Végétation", v(parc, 'frac_vegetale', '{:.0%}'), self.EXPLICATIONS["vegetation"])
            + indicateur("Emprise bâtie (CES)", v(parc, 'coef_emprise_sol', '{:.0%}'), self.EXPLICATIONS["ces"])
            + indicateur("Hauteur bâtie moyenne", v(parc, 'hauteur_bati_moy', '{:.0f} m'), self.EXPLICATIONS["hauteur"])
            + "</div>")

        if rga_txt:
            couleur_rga = {"faible": "#3e9651", "moyen": "#e08a19",
                           "fort": "#d13f35"}.get(rga_txt, "#666")
            html += (
                "<div class='card'><h2>🧱 Sols argileux</h2>"
                "<p>Exposition au retrait-gonflement : "
                "<span class='rga' style='color:" + couleur_rga + ";'>"
                + rga_txt + "</span></p>"
                "<p class='explain'>ⓘ " + self.EXPLICATIONS["rga"] + "</p></div>")

        if tron is not None:
            html += (
                "<div class='card'><h2>🛣️ Rue la plus proche</h2>"
                "<table class='infos'>"
                "<tr><td>Nom de la voie</td><td>" + v(tron, 'nom_voie') + "</td></tr>"
                "<tr><td>Distance</td><td>" + f"{dist:.0f} m" + "</td></tr>"
                "<tr><td>Écart de chaleur</td><td>" + v(tron, 'suhi_c', '{:+.1f} °C') + "</td></tr>"
                "</table>"
                "<p class='explain'>ⓘ Écart de température de surface mesuré pour le tronçon de rue le plus proche.</p>"
                "</div>")

        reperes = self._reperes_agent(suhi_n, imperm_n, veg_n, rga_txt)
        html += "<div class='card'><h2>🔑 Points à retenir</h2>"
        for repere in reperes:
            html += "<div class='repere'>" + repere + "</div>"
        html += (
            "<p class='note'>Ces informations viennent de données de zonage. "
            "Elles ne remplacent pas un diagnostic réglementaire ou une estimation immobilière.</p>"
            "</div>")

        self._zoomer(parc)
        self._ouvrir_fenetre(html, adresse)

    def _zoomer(self, parcelle):
        canvas = self.iface.mapCanvas()
        tr = QgsCoordinateTransform(CRS_PACK,
                                    QgsProject.instance().crs(),
                                    QgsProject.instance())
        geom = QgsGeometry(parcelle.geometry())
        geom.transform(tr)

        self._effacer_surbrillance()
        self.rubber = QgsRubberBand(canvas, Qgis.GeometryType.Polygon)
        self.rubber.setToGeometry(geom, None)
        self.rubber.setColor(QColor(255, 80, 0, 90))
        self.rubber.setStrokeColor(QColor(230, 60, 0))
        self.rubber.setWidth(2)

        emprise = geom.boundingBox()
        emprise.scale(4)
        canvas.setExtent(emprise)
        canvas.refresh()

    def _effacer_surbrillance(self):
        if self.rubber:
            self.iface.mapCanvas().scene().removeItem(self.rubber)
            self.rubber = None
