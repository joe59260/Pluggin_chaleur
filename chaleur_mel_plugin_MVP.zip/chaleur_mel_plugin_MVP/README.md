##### Chaleur MEL

Petit plugin QGIS que j'ai fait pour chercher une adresse dans la MEL et voir les infos sur la chaleur autour de la parcelle.

Il affiche la chaleur de surface, le type de quartier, la végétation, l'imperméabilisation, le bati et quelques infos sur la rue proche.Actuellement en version MVP, en date du 15 juillet 2026





Installation

Installer le zip depuis le menu Extensions de QGIS.
Au premier lancement il télécharge les données nécessaires.Le pack est joint avec des données en libre accès et versionnés pour les V2, V3 etc 



Attention : les températures satellite sont des températures de surface et pas la température de l'air. Pour une petite parcelle la valeur peut venir du pixel
d'à coté.

