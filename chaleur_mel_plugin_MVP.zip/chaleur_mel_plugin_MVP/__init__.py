def classFactory(iface):
    from .chaleur_mel_plugin import ChaleurMelPlugin
    return ChaleurMelPlugin(iface)
