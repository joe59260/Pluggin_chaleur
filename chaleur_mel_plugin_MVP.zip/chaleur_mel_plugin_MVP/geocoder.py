import json
from urllib.parse import urlencode

from qgis.core import QgsBlockingNetworkRequest
from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtNetwork import QNetworkRequest

URL_GEOCODAGE = "https://data.geopf.fr/geocodage/search/"

# biais autours de Lille
BIAIS_LAT, BIAIS_LON = 50.63, 3.06


def geocoder(texte, limite=6):
    texte = (texte or "").strip()
    if len(texte) < 3:
        return []

    params = urlencode({
        "q": texte,
        "limit": limite,
        "lat": BIAIS_LAT,
        "lon": BIAIS_LON,
        "index": "address",
    })
    req = QgsBlockingNetworkRequest()
    if req.get(QNetworkRequest(QUrl(f"{URL_GEOCODAGE}?{params}"))) != \
            QgsBlockingNetworkRequest.NoError:
        return []

    try:
        data = json.loads(bytes(req.reply().content()).decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return []

    resultats = []
    for feat in data.get("features", []):
        try:
            lon, lat = feat["geometry"]["coordinates"][:2]
            props = feat.get("properties", {})
            resultats.append({
                "label": props.get("label", "adresse"),
                "lon": float(lon),
                "lat": float(lat),
                "score": props.get("score"),
                "citycode": props.get("citycode"),
            })
        except (KeyError, TypeError, ValueError):
            continue
    return resultats
